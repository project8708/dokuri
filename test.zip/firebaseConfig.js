// firebaseConfig.js
const firebaseConfig = {
    apiKey: "AIzaSyCI2U6rdm1dVqHa4KTBO7ebiO49cnnM7W4",
    authDomain: "acoustic-arch-320110.firebaseapp.com",
    databaseURL: "https://acoustic-arch-320110-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "acoustic-arch-320110",
    storageBucket: "acoustic-arch-320110.appspot.com",
    messagingSenderId: "975479821242",
    appId: "1:975479821242:web:a6b4d128893cdec1100383",
    measurementId: "G-BGTD7LKT1C"
};

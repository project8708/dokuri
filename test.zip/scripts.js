// scripts.js

// Firebase 초기화
firebase.initializeApp(firebaseConfig);
const db = firebase.database();

let cart = [];

document.addEventListener("DOMContentLoaded", () => {
    const menuContainer = document.getElementById('menu-container');
    const menuItems = parseMenuData(menuData);
    menuItems.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'menu-item';
        itemElement.innerHTML = `${item.name} - ${item.price}원 <button onclick="addToCart('${item.name}', ${item.price})">+</button>`;
        menuContainer.appendChild(itemElement);
    });
});

function parseMenuData(data) {
    const items = [];
    const lines = data.trim().split('\n');
    let currentCategory = '';
    let currentSubcategory = '';

    lines.forEach(line => {
        if (line.startsWith('[')) {
            currentCategory = line.slice(1, -1);
        } else if (line.includes('- {')) {
            currentSubcategory = line.split('- {')[1].slice(0, -1);
        } else if (line.includes('(옵션')) {
            const [name, price] = line.split(')');
            const option = name.split('(')[1];
            const itemName = currentCategory + ' ' + option;
            items.push({name: itemName.trim(), price: parseInt(price.trim().replace(',', ''))});
        } else {
            const [name, price] = line.split(/\s{2,}/);
            const itemName = currentCategory + ' ' + (currentSubcategory ? currentSubcategory + ' ' : '') + name;
            items.push({name: itemName.trim(), price: parseInt(price.trim().replace(',', ''))});
        }
    });

    return items;
}

function addToCart(name, price) {
    cart.push({name, price});
    showFeedback(`${name}이(가) 장바구니에 담겼습니다.`);
}

function showFeedback(message) {
    const feedback = document.createElement('div');
    feedback.className = 'feedback';
    feedback.innerHTML = message;
    document.body.appendChild(feedback);
    setTimeout(() => {
        feedback.remove();
    }, 2000);
}

function toggleCart() {
    const cartContainer = document.getElementById('cart-container');
    cartContainer.classList.toggle('hidden');
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = cart.map(item => `<div>${item.name} - ${item.price}원</div>`).join('');
}

function sendOrder() {
    const orderRef = db.ref('orders');
    orderRef.push(cart).then(() => {
        alert('주문이 성공적으로 전송되었습니다.');
        cart = [];
        toggleCart();
    });
}
